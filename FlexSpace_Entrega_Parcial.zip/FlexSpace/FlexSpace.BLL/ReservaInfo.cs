using System;

namespace FlexSpace.BLL
{
    public class ReservaInfo
    {
        public int Id { get; set; }
        public string Cliente { get; set; }
        public string Puesto { get; set; }
        public DateTime Inicio { get; set; }
        public DateTime Fin { get; set; }
        public decimal Costo { get; set; }
    }
}
