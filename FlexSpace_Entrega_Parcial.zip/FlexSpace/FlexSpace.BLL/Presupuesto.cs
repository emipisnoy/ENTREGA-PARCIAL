namespace FlexSpace.BLL
{
    public class Presupuesto
    {
        public string Cliente { get; set; }
        public string Puesto { get; set; }
        public decimal Horas { get; set; }
        public decimal Subtotal { get; set; }
        public decimal RecargoFinDeSemana { get; set; }
        public decimal DescuentoVolumen { get; set; }
        public decimal DescuentoVip { get; set; }
        public decimal PenalizacionSanciones { get; set; }
        public decimal Total { get; set; }
    }
}
