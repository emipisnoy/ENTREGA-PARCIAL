namespace FlexSpace.BLL
{
    public class ClienteInfo
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public int Sanciones { get; set; }
    }
}
