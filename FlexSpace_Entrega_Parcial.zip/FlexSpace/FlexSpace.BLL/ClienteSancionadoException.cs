using System;

namespace FlexSpace.BLL
{
    public class ClienteSancionadoException : Exception
    {
        public ClienteSancionadoException(string nombre, int sanciones)
            : base("El cliente " + nombre + " tiene " + sanciones + " sanciones activas y no puede realizar reservas.")
        {
        }
    }
}
