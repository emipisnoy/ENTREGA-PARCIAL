using System.Collections.Generic;
using FlexSpace.DAL;

namespace FlexSpace.BLL
{
    public class ClienteBLL
    {
        private ClienteDAL clienteDAL = new ClienteDAL();

        public ClienteBLL()
        {
            Conexion.CrearTablas();
        }

        public List<ClienteInfo> ListarSancionados()
        {
            List<ClienteInfo> lista = new List<ClienteInfo>();
            foreach (Cliente c in clienteDAL.ObtenerSancionados())
            {
                ClienteInfo info = new ClienteInfo();
                info.Id = c.Id;
                info.Nombre = c.Nombre;
                info.Tipo = c.TipoCliente.ToString();
                info.Sanciones = c.SancionesActivas;
                lista.Add(info);
            }
            return lista;
        }
    }
}
