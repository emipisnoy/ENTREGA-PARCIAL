using System;
using FlexSpace.BLL;

namespace FlexSpace.UI
{
    class Program
    {
        private static ReservaBLL reservaBLL = new ReservaBLL();

        static void Main(string[] args)
        {
            Console.WriteLine("===== FlexSpace - Gestor de Coworking =====");
            Console.WriteLine("1. Registrar nueva reserva");
            Console.WriteLine("2. Cancelar reserva (En desarrollo)");
            Console.WriteLine("3. Consultar reservas activas (En desarrollo)");
            Console.WriteLine("4. Listar clientes sancionados (En desarrollo)");
            Console.WriteLine("0. Salir");

            Console.Write("\nSeleccione una opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    RegistrarReserva();
                    break;
                case "2":
                    Console.WriteLine("Módulo de cancelación en desarrollo.");
                    break;
                default:
                    Console.WriteLine("Opción no implementada o inválida.");
                    break;
            }
        }

        static void RegistrarReserva()
        {
            try
            {
                Console.Write("ID del cliente: ");
                int clienteId = int.Parse(Console.ReadLine());

                Console.Write("ID del puesto: ");
                int puestoId = int.Parse(Console.ReadLine());

                // TODO: Completar la lectura de fechas (inicio y fin)
                
                Console.WriteLine("\n[Lógica de registro parcial]");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
