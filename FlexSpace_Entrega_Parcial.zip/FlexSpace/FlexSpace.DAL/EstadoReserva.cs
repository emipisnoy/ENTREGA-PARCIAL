namespace FlexSpace.DAL
{
    public enum EstadoReserva
    {
        Confirmada,
        Cancelada,
        Finalizada
    }
}
