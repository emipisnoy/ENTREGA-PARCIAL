using System;
using System.Globalization;
using Microsoft.Data.Sqlite;

namespace FlexSpace.DAL
{
    public class Conexion
    {
        private const string Cadena = "Data Source=flexspace.db";
        private const string FormatoFecha = "yyyy-MM-dd HH:mm:ss";

        public static SqliteConnection Abrir()
        {
            SqliteConnection con = new SqliteConnection(Cadena);
            con.Open();
            return con;
        }

        public static string FechaATexto(DateTime fecha)
        {
            return fecha.ToString(FormatoFecha, CultureInfo.InvariantCulture);
        }

        public static DateTime TextoAFecha(string texto)
        {
            return DateTime.ParseExact(texto, FormatoFecha, CultureInfo.InvariantCulture);
        }

        // Crea las tablas si no existen y carga datos de prueba la primera vez
        public static void CrearTablas()
        {
            using (SqliteConnection con = Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText =
                    "CREATE TABLE IF NOT EXISTS Clientes (" +
                    "Id INTEGER PRIMARY KEY AUTOINCREMENT, Nombre TEXT NOT NULL, Email TEXT NOT NULL, " +
                    "TipoCliente TEXT NOT NULL, SancionesActivas INTEGER NOT NULL DEFAULT 0);" +
                    "CREATE TABLE IF NOT EXISTS Puestos (" +
                    "Id INTEGER PRIMARY KEY AUTOINCREMENT, Codigo TEXT NOT NULL UNIQUE, " +
                    "TipoPuesto TEXT NOT NULL, TarifaBasePorHora REAL NOT NULL);" +
                    "CREATE TABLE IF NOT EXISTS Reservas (" +
                    "Id INTEGER PRIMARY KEY AUTOINCREMENT, ClienteId INTEGER NOT NULL, PuestoId INTEGER NOT NULL, " +
                    "FechaInicio TEXT NOT NULL, FechaFin TEXT NOT NULL, Estado TEXT NOT NULL, CostoTotal REAL NOT NULL);";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "SELECT COUNT(*) FROM Clientes";
                int cantidad = Convert.ToInt32(cmd.ExecuteScalar());
                if (cantidad == 0)
                {
                    cmd.CommandText =
                        "INSERT INTO Clientes (Nombre, Email, TipoCliente, SancionesActivas) VALUES " +
                        "('Ana Perez', 'ana@mail.com', 'Estandar', 0), " +
                        "('Bruno Gomez', 'bruno@mail.com', 'VIP', 0), " +
                        "('Carla Ruiz', 'carla@mail.com', 'Estandar', 1), " +
                        "('Diego Soto', 'diego@mail.com', 'VIP', 3);" +
                        "INSERT INTO Puestos (Codigo, TipoPuesto, TarifaBasePorHora) VALUES " +
                        "('ESC-01', 'EscritorioIndividual', 1000), " +
                        "('SAL-01', 'SalaReuniones', 3500), " +
                        "('CAB-01', 'CabinaPrivada', 2000);";
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
