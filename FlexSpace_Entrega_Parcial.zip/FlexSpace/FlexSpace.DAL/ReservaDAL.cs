using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;

namespace FlexSpace.DAL
{
    public class ReservaDAL
    {
        public bool HaySolapamiento(int puestoId, DateTime inicio, DateTime fin)
        {
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "SELECT COUNT(*) FROM Reservas WHERE PuestoId = @puesto AND Estado = 'Confirmada' " +
                                  "AND FechaInicio < @fin AND FechaFin > @inicio";
                cmd.Parameters.AddWithValue("@puesto", puestoId);
                cmd.Parameters.AddWithValue("@inicio", Conexion.FechaATexto(inicio));
                cmd.Parameters.AddWithValue("@fin", Conexion.FechaATexto(fin));
                int cantidad = Convert.ToInt32(cmd.ExecuteScalar());
                return cantidad > 0;
            }
        }

        public int Insertar(Reserva reserva)
        {
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO Reservas (ClienteId, PuestoId, FechaInicio, FechaFin, Estado, CostoTotal) " +
                                  "VALUES (@cliente, @puesto, @inicio, @fin, @estado, @costo)";
                cmd.Parameters.AddWithValue("@cliente", reserva.ClienteId);
                cmd.Parameters.AddWithValue("@puesto", reserva.PuestoId);
                cmd.Parameters.AddWithValue("@inicio", Conexion.FechaATexto(reserva.FechaInicio));
                cmd.Parameters.AddWithValue("@fin", Conexion.FechaATexto(reserva.FechaFin));
                cmd.Parameters.AddWithValue("@estado", reserva.Estado.ToString());
                cmd.Parameters.AddWithValue("@costo", (double)reserva.CostoTotal);
                cmd.ExecuteNonQuery();

                cmd.CommandText = "SELECT last_insert_rowid()";
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public Reserva ObtenerPorId(int id)
        {
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, ClienteId, PuestoId, FechaInicio, FechaFin, Estado, CostoTotal FROM Reservas WHERE Id = @id";
                cmd.Parameters.AddWithValue("@id", id);
                SqliteDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return Leer(dr);
                }
                return null;
            }
        }

        public List<Reserva> ObtenerFuturasPorPuesto(int puestoId, DateTime desde)
        {
            List<Reserva> lista = new List<Reserva>();
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, ClienteId, PuestoId, FechaInicio, FechaFin, Estado, CostoTotal FROM Reservas " +
                                  "WHERE PuestoId = @puesto AND Estado = 'Confirmada' AND FechaInicio > @desde ORDER BY FechaInicio";
                cmd.Parameters.AddWithValue("@puesto", puestoId);
                cmd.Parameters.AddWithValue("@desde", Conexion.FechaATexto(desde));
                SqliteDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    lista.Add(Leer(dr));
                }
            }
            return lista;
        }

        public void Cancelar(int id)
        {
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Reservas SET Estado = 'Cancelada' WHERE Id = @id";
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
        }

        private Reserva Leer(SqliteDataReader dr)
        {
            Reserva r = new Reserva();
            r.Id = dr.GetInt32(0);
            r.ClienteId = dr.GetInt32(1);
            r.PuestoId = dr.GetInt32(2);
            r.FechaInicio = Conexion.TextoAFecha(dr.GetString(3));
            r.FechaFin = Conexion.TextoAFecha(dr.GetString(4));
            r.Estado = (EstadoReserva)Enum.Parse(typeof(EstadoReserva), dr.GetString(5));
            r.CostoTotal = Convert.ToDecimal(dr.GetValue(6));
            return r;
        }
    }
}
