namespace FlexSpace.DAL
{
    public enum TipoPuesto
    {
        EscritorioIndividual,
        SalaReuniones,
        CabinaPrivada
    }
}
