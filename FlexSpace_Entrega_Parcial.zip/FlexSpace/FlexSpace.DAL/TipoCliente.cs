namespace FlexSpace.DAL
{
    public enum TipoCliente
    {
        Estandar,
        VIP
    }
}
