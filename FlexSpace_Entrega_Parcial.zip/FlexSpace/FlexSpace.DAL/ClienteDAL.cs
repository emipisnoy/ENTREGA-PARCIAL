using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;

namespace FlexSpace.DAL
{
    public class ClienteDAL
    {
        public Cliente ObtenerPorId(int id)
        {
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, Nombre, Email, TipoCliente, SancionesActivas FROM Clientes WHERE Id = @id";
                cmd.Parameters.AddWithValue("@id", id);
                SqliteDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return Leer(dr);
                }
                return null;
            }
        }

        public List<Cliente> ObtenerSancionados()
        {
            List<Cliente> lista = new List<Cliente>();
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, Nombre, Email, TipoCliente, SancionesActivas FROM Clientes WHERE SancionesActivas > 0";
                SqliteDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    lista.Add(Leer(dr));
                }
            }
            return lista;
        }

        public void SumarSancion(int clienteId)
        {
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Clientes SET SancionesActivas = SancionesActivas + 1 WHERE Id = @id";
                cmd.Parameters.AddWithValue("@id", clienteId);
                cmd.ExecuteNonQuery();
            }
        }

        private Cliente Leer(SqliteDataReader dr)
        {
            Cliente c = new Cliente();
            c.Id = dr.GetInt32(0);
            c.Nombre = dr.GetString(1);
            c.Email = dr.GetString(2);
            c.TipoCliente = (TipoCliente)Enum.Parse(typeof(TipoCliente), dr.GetString(3));
            c.SancionesActivas = dr.GetInt32(4);
            return c;
        }
    }
}
