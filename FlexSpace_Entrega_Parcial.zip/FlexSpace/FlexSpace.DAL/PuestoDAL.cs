using System;
using Microsoft.Data.Sqlite;

namespace FlexSpace.DAL
{
    public class PuestoDAL
    {
        public Puesto ObtenerPorId(int id)
        {
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, Codigo, TipoPuesto, TarifaBasePorHora FROM Puestos WHERE Id = @id";
                cmd.Parameters.AddWithValue("@id", id);
                SqliteDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return Leer(dr);
                }
                return null;
            }
        }

        public Puesto ObtenerPorCodigo(string codigo)
        {
            using (SqliteConnection con = Conexion.Abrir())
            {
                SqliteCommand cmd = con.CreateCommand();
                cmd.CommandText = "SELECT Id, Codigo, TipoPuesto, TarifaBasePorHora FROM Puestos WHERE Codigo = @codigo COLLATE NOCASE";
                cmd.Parameters.AddWithValue("@codigo", codigo);
                SqliteDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return Leer(dr);
                }
                return null;
            }
        }

        private Puesto Leer(SqliteDataReader dr)
        {
            Puesto p = new Puesto();
            p.Id = dr.GetInt32(0);
            p.Codigo = dr.GetString(1);
            p.TipoPuesto = (TipoPuesto)Enum.Parse(typeof(TipoPuesto), dr.GetString(2));
            p.TarifaBasePorHora = Convert.ToDecimal(dr.GetValue(3));
            return p;
        }
    }
}
